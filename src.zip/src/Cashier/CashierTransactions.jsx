

const CashierTransactions = () => {
  return (
    <div>CashierTransactions</div>
  )
}

export default CashierTransactions