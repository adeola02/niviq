

const CashierHomePage = () => {
  return (
    <div>CashierHomePage</div>
  )
}

export default CashierHomePage