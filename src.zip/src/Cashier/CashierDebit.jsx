

const CashierDebit = () => {
  return (
    <div>CashierDebit</div>
  )
}

export default CashierDebit