

const CashierTransfer = () => {
  return (
    <div>CashierTransfer</div>
  )
}

export default CashierTransfer