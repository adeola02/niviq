

const Cashier = () => {
  return (
    <div>Cashier</div>
  )
}

export default Cashier