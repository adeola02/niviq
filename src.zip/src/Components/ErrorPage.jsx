

const ErrorPage = () => {
  return (
    <div>
      THE PAGE YOU ARE LOOKING FOR IS NOT FOUND 
      <button className="w-max h-max px-6 py-2 bg-[#ddd]">Go Back Home</button>
    </div>
  )
}

export default ErrorPage