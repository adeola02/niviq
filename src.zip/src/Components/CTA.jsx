import React from 'react'

const CTA = () => {
  return (
    <div>
      
    </div>
  )
}

export default CTA
