import React from 'react'

const Stats = () => {
  return (
    <div>
      stats
    </div>
  )
}

export default Stats
