
const UserLoan = () => {
  return (
    <div>UserLoan</div>
  )
}

export default UserLoan